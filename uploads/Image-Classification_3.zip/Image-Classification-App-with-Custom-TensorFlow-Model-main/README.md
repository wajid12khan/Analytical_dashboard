# Image-Classification-App-with-Custom-TensorFlow-Model
Learn how to code your own neural network in Python, then deploy it in an Image Classification App using TensorFlow Lite.
